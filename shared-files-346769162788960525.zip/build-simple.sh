#!/bin/bash
set -e

# Simple build script for music 2027 app
# This script attempts to create a basic APK using available build tools

WORKSPACE="/storage/emulated/0/Android/data/com.androidharness.app/files/workspace"
APK_DIR="$WORKSPACE/build/apk"

# Check if Android SDK is available
if [ ! -f "$HOME/android-sdk/platforms/android-35/android.jar" ]; then
    echo "Error: android.jar not found. Please install Android SDK."
    exit 1
fi

# Check if required tools are available
tools=("aapt2" "d8" "apksigner")
for tool in "${tools[@]}"; do
    if ! command -v $tool &> /dev/null; then
        echo "Error: $tool not found. Please install build tools."
        exit 1
    fi
done

# Create directories
mkdir -p "$APK_DIR"

# Create a simple AndroidManifest.xml if it doesn't exist
if [ ! -f "$WORKSPACE/app/src/main/AndroidManifest.xml" ]; then
    cat > "$WORKSPACE/app/src/main/AndroidManifest.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.music2027.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />

    <application
        android:name=".Music2027Application"
        android:icon="@mipmap/ic_launcher"
        android:label="music 2027"
        android:theme="@style/Theme.Music2027">

        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".player.MusicPlaybackService"
            android:exported="true"
            android:foregroundServiceType="mediaPlayback">
        </service>
    </application>
</manifest>
EOF
fi

# Create a basic resources directory if it doesn't exist
if [ ! -d "$WORKSPACE/app/src/main/res/values" ]; then
    mkdir -p "$WORKSPACE/app/src/main/res/values"
    cat > "$WORKSPACE/app/src/main/res/values/strings.xml" << 'EOF'
<resources>
    <string name="app_name">music 2027</string>
    <string name="hello_world">Hello, Music 2027!</string>
    <string name="play">Play</string>
    <string name="pause">Pause</string>
    <string name="next">Next</string>
    <string name="previous">Previous</string>
    <string name="shuffle">Shuffle</string>
    <string name="repeat">Repeat</string>
    <string name="like">Like</string>
    <string name="liked">Liked</string>
</resources>
EOF
fi

# Create basic source files if they don't exist
if [ ! -f "$WORKSPACE/app/src/main/java/com/music2027/app/MainActivity.kt" ]; then
    cat > "$WORKSPACE/app/src/main/java/com/music2027/app/MainActivity.kt" << 'EOF'
package com.music2027.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstance: Bundle?) {
        super.onCreate(savedInstance)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Music2027App()
                }
            }
        }
    }
}

@Composable
fun Music2027App() {
    Text(
        text = "🎵 Music 2027",
        style = MaterialTheme.typography.headlineLarge
    )
}
EOF
fi

# Create a basic build.gradle.kts if it doesn't exist
if [ ! -f "$WORKSPACE/app/build.gradle.kts" ]; then
    cat > "$WORKSPACE/app/build.gradle.kts" << 'EOF'
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.music2027.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.music2027.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "2027.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.compose.material3:material3:1.3.0")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.navigation:navigation-compose:2.8.2")
}
EOF
fi

# Try to build the project
echo "Building music 2027 app..."
cd "$WORKSPACE" && gradle assembleDebug --no-daemon 2>&1 | tail -30

# Check if APK was created
if [ -f "$APK_DIR/com.music2027.app.apk" ]; then
    echo "✅ Build successful! APK created at: $APK_DIR/com.music2027.app.apk"
else
    echo "❌ Build failed. No APK created."
    echo "Please check the build output for errors."
fi
EOF
chmod +x build-simple.sh
