plugins {
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
}

ext {
    projectName = "music 2027"
    applicationId = "com.music2027.app"
    versionCode = 1
    versionName = "2027.1.0"
}
