#!/bin/bash
set -e

# Create minimal APK for music 2027 app
# This is a demonstration of the project structure and build process

WORKSPACE="/storage/emulated/0/Android/data/com.androidharness.app/files/workspace"
APK_DIR="$WORKSPACE/build/apk"

# Create directories
mkdir -p "$APK_DIR"

# Create a minimal AndroidManifest.xml
MANIFEST="$WORKSPACE/app/src/main/AndroidManifest.xml"
if [ ! -f "$MANIFEST" ]; then
    cat > "$MANIFEST" << 'XMLEOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.music2027.app"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:name=".Music2027Application"
        android:icon="@mipmap/ic_launcher"
        android:label="music 2027"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:theme="@style/Theme.Music2027"
        tools:targetApi="31">

        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
XMLEOF
fi

# Create a minimal resources structure
RES_DIR="$WORKSPACE/app/src/main/res/values"
mkdir -p "$RES_DIR"
if [ ! -f "$RES_DIR/strings.xml" ]; then
    cat > "$RES_DIR/strings.xml" << 'XMLEOF'
<resources>
    <string name="app_name">music 2027</string>
    <string name="hello_world">Hello, Music 2027!</string>
    <string name="play">Play</string>
    <string name="pause">Pause</string>
    <string name="next">Next</string>
    <string name="previous">Previous</string>
    <string name="shuffle">Shuffle</string>
    <string name="repeat">Repeat</string>
</resources>
XMLEOF
fi

# Create a minimal MainActivity.kt
SRC_DIR="$WORKSPACE/app/src/main/java/com/music2027/app"
mkdir -p "$SRC_DIR"
if [ ! -f "$SRC_DIR/MainActivity.kt" ]; then
    cat > "$SRC_DIR/MainActivity.kt" << 'KOTLINEOF'
package com.music2027.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Text(
                        text = "🎵 Music 2027",
                        style = MaterialTheme.typography.headlineLarge
                    )
                }
            }
        }
    }
}
KOTLINEOF
fi

# Create minimal theme
THEME_DIR="$WORKSPACE/app/src/main/res/values"
mkdir -p "$THEME_DIR"
if [ ! -f "$THEME_DIR/themes.xml" ]; then
    cat > "$THEME_DIR/themes.xml" << 'XMLEOF'
<resources>
    <style name="Theme.Music2027" parent="Theme.Material3.DayNight.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorBackground">@color/background</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
    </style>
</resources>
XMLEOF
fi

# Create colors.xml
if [ ! -f "$THEME_DIR/colors.xml" ]; then
    cat > "$THEME_DIR/colors.xml" << 'XMLEOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#2196F3</color>
    <color name="background">#FFFFFF</color>
    <color name="on_background">#000000</color>
</resources>
XMLEOF
fi

# Create launcher icons
for density in mdpi hdpi xhdpi; do
    ICON_DIR="$WORKSPACE/app/src/main/res/mipmap-$density"
    mkdir -p "$ICON_DIR"
    if [ ! -f "$ICON_DIR/ic_launcher.xml" ]; then
        cat > "$ICON_DIR/ic_launcher.xml" << 'XMLEOF'
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@android:color/white"
        android:pathData="M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"/>
</vector>
XMLEOF
    fi
done

echo "APK structure for music 2027 app created successfully!"
echo "APK would be built at: $APK_DIR/com.music2027.app.apk"
