package com.music2027.app.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val artistId: String,
    val album: String,
    val albumId: String,
    val duration: Long,
    val artworkUrl: String?,
    val audioUrl: String?,
    val isExplicit: Boolean = false,
    val isLiked: Boolean = false,
    val playCount: Long = 0,
    val trackNumber: Int = 0,
    val year: Int = 0,
    val genre: String = "",
) : Parcelable {

    companion object {
        fun createSample(
            id: String = "song_$id",
            title: String = "Sample Song",
            artist: String = "Sample Artist",
            album: String = "Sample Album",
        ): Song = Song(
            id = id,
            title = title,
            artist = artist,
            artistId = "artist_1",
            album = album,
            albumId = "album_1",
            duration = 180000L,
            artworkUrl = "https://picsum.photos/seed/$id/300/300",
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            trackNumber = 1,
            year = 2024,
            genre = "Pop",
        )
    }

    fun formattedDuration(): String {
        val minutes = duration / 60000
        val seconds = (duration % 60000) / 1000
        return "%d:%02d".format(minutes, seconds)
    }
}
