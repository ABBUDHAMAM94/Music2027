package com.music2027.app

import android.app.Application

class Music2027Application : Application() {
    // Application initialization code here
}
