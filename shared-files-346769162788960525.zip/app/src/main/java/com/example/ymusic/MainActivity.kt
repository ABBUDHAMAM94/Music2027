package com.example.ymusic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.BottomNavigation
import androidx.compose.material3.BottomNavigationItem
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ymusic.model.Song
import com.example.ymusic.player.MediaPlaybackService
import com.example.ymusic.ui.screen.AppNavHost
import com.example.ymusic.ui.screen.Screen
import com.example.ymusic.ui.theme.YMusicTheme
import com.example.ymusic.ui.theme.ymusicSurface
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.ProgressIndicator
import androidx.compose.runtime.collectAsStateWithLifecycle
import androidx.media3.session.MediaController
import androidx.media3.session.MediaControllerCompat
import androidx.media3.session.SessionCommand

class MainActivity : ComponentActivity() {

    private val repository: MusicRepository by viewModel()
    private val playbackService: MediaPlaybackService by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YMusicTheme.apply {
                YMusicApp(repository, playbackService)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YMusicApp(
    repository: MusicRepository,
    playbackService: MediaPlaybackService
) {
    val navController = rememberNavController()
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf(Screen.Home, Screen.Library, Screen.Search)

    // Observe playback state for mini player
    val currentSong by playbackService.currentSong.collectAsStateWithLifecycle()
    val playbackState by playbackService.playbackState.collectAsStateWithLifecycle()
    val showMiniPlayer = currentSong != null && playbackState != MediaPlaybackService.PlaybackState.Idle

    YMusicTheme.apply {
        ymusicSurface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                // Main navigation content
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = if (showMiniPlayer) 72.dp else 56.dp)
                ) {
                    AppNavHost(navController)
                }

                // Mini player
                if (showMiniPlayer) {
                    MiniPlayer(
                        song = currentSong!!,
                        isPlaying = playbackState == MediaPlaybackService.PlaybackState.Playing,
                        onPlayPause = { playbackService.togglePlayPause() },
                        onNext = { playbackService.skipNext() },
                        onExpand = { navController.navigate(Screen.NowPlaying.route) }
                    )
                }

                // Bottom navigation
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    tabs.forEachIndexed { index, screen ->
                        NavigationBarItem(
                            icon = { Icon(
                                painter = when (screen) {
                                    Screen.Home -> painterResource(id = androidx.compose.material.icons.filled.Home)
                                    Screen.Library -> painterResource(id = androidx.compose.material.icons.filled.LibraryMusic)
                                    Screen.Search -> painterResource(id = androidx.compose.material.icons.filled.Search)
                                    else -> painterResource(id = androidx.compose.material.icons.filled.Home)
                                },
                                contentDescription = screen.route,
                                tint = if (selectedTab == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )},
                            label = { Text(
                                text = stringResource(id = when (screen) {
                                    Screen.Home -> R.string.home
                                    Screen.Library -> R.string.library
                                    Screen.Search -> R.string.search
                                    else -> R.string.home
                                }),
                                fontSize = 10.sp,
                                color = if (selectedTab == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )},
                            selected = selectedTab == index,
                            onClick = {
                                selectedTab = index
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    avoidMultipleCopies = true
                                }
                            },
                            alwaysShowLabel = false
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onExpand: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    
    androidx.compose.material3.Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .fillMaxWidth()
            .clickable(onClick = onExpand)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = colors.surfaceContainerHigh,
        ),
        shape = MaterialTheme.shapes.medium
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            // Artwork
            androidx.compose.foundation.layout.Box(
                modifier = Modifier.size(48.dp).clip(MaterialTheme.shapes.small)
            ) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_music_note),
                    contentDescription = "Album art",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Song info
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
                    .fillMaxHeight()
            ) {
                Text(
                    text = song.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                    color = colors.onSurface
                )
                Text(
                    text = song.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp,
                    color = colors.onSurfaceVariant
                )
            }

            // Controls
            androidx.compose.foundation.layout.Row(
                modifier = Modifier.padding(end = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { /* previous */ }) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = colors.onSurface)
                }
                IconButton(onClick = onPlayPause) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = colors.primary
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = colors.onSurface)
                }
            }
        }
    }
}
