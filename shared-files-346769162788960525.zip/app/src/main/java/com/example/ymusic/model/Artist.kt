package com.example.ymusic.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class Artist(
    val id: String,
    val name: String,
    val artworkUrl: String?,
    val bannerUrl: String?,
    val subscriberCount: Long = 0,
    val description: String = "",
    val genres: List<String> = emptyList(),
    val topSongs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val relatedArtists: List<Artist> = emptyList(),
) : Parcelable {

    companion object {
        fun createSample(
            id: String = "artist_$id",
            name: String = "Sample Artist",
        ): Artist = Artist(
            id = id,
            name = name,
            artworkUrl = "https://picsum.photos/seed/$id/400/400",
            bannerUrl = "https://picsum.photos/seed/${id}_banner/1200/400",
            subscriberCount = (1000..1000000).random().toLong(),
        )
    }
}
