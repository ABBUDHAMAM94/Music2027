package com.example.ymusic.ui.screen

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ymusic.model.Album
import com.example.ymusic.model.Artist
import com.example.ymusic.model.Playlist
import com.example.ymusic.model.Song

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Library : Screen("library")
    object Search : Screen("search")
    object NowPlaying : Screen("now_playing")
    data class AlbumDetail(val album: Album) : Screen("album/${album.id}")
    data class ArtistDetail(val artist: Artist) : Screen("artist/${artist.id}")
    data class PlaylistDetail(val playlist: Playlist) : Screen("playlist/${playlist.id}")
    data class SongDetail(val song: Song, val queue: List<Song>, val index: Int) : Screen("song/${song.id}")
}

@Composable
fun AppNavHost(navController: NavHostController, startDestination: String = Screen.Home.route) {
    NavHost(navController, startDestination) {
        composable(Screen.Home.route) {
            HomeScreen(onNavigate = { screen ->
                navController.navigate(screen.route)
            })
        }
        composable(Screen.Library.route) {
            LibraryScreen(onNavigate = { screen ->
                navController.navigate(screen.route)
            })
        }
        composable(Screen.Search.route) {
            SearchScreen(onNavigate = { screen ->
                navController.navigate(screen.route)
            })
        }
        composable(
            route = Screen.NowPlaying.route,
            arguments = androidx.navigation.navArgument("song") { type = androidx.navigation.SongParcelableType() },
        ) { backStackEntry ->
            val song = backStackEntry.getParcelable<Song>("song")!!
            val queue = backStackEntry.getParcelableArrayList<Song>("queue")?.toList() ?: emptyList()
            val index = backStackEntry.getInt("index")
            NowPlayingScreen(song = song, queue = queue, index = index)
        }
        composable(
            route = "album/{albumId}",
            arguments = listOf(androidx.navigation.navArgument("albumId") { type = androidx.navigation.AlbumParcelableType() })
        ) { backStackEntry ->
            val album = backStackEntry.getParcelable<Album>("albumId")!!
            AlbumDetailScreen(album = album)
        }
        composable(
            route = "artist/{artistId}",
            arguments = listOf(androidx.navigation.navArgument("artistId") { type = androidx.navigation.ArtistParcelableType() })
        ) { backStackEntry ->
            val artist = backStackEntry.getParcelable<Artist>("artistId")!!
            ArtistDetailScreen(artist = artist)
        }
        composable(
            route = "playlist/{playlistId}",
            arguments = listOf(androidx.navigation.navArgument("playlistId") { type = androidx.navigation.PlaylistParcelableType() })
        ) { backStackEntry ->
            val playlist = backStackEntry.getParcelable<Playlist>("playlistId")!!
            PlaylistDetailScreen(playlist = playlist)
        }
    }
}

// Parcelable type helpers for navigation
private class SongParcelableType : androidx.navigation.NavType<Song>(true) {
    override fun get(bundle: Bundle, key: String): Song? = bundle.getParcelable(key)
    override fun put(bundle: Bundle, key: String, value: Song) { bundle.putParcelable(key, value) }
    override fun parseValue(value: String): Song = throw UnsupportedOperationException()
    override val name = "Song"
}

private class AlbumParcelableType : androidx.navigation.NavType<Album>(true) {
    override fun get(bundle: Bundle, key: String): Album? = bundle.getParcelable(key)
    override fun put(bundle: Bundle, key: String, value: Album) { bundle.putParcelable(key, value) }
    override fun parseValue(value: String): Album = throw UnsupportedOperationException()
    override val name = "Album"
}

private class ArtistParcelableType : androidx.navigation.NavType<Artist>(true) {
    override fun get(bundle: Bundle, key: String): Artist? = bundle.getParcelable(key)
    override fun put(bundle: Bundle, key: String, value: Artist) { bundle.putParcelable(key, value) }
    override fun parseValue(value: String): Artist = throw UnsupportedOperationException()
    override val name = "Artist"
}

private class PlaylistParcelableType : androidx.navigation.NavType<Playlist>(true) {
    override fun get(bundle: Bundle, key: String): Playlist? = bundle.getParcelable(key)
    override fun put(bundle: Bundle, key: String, value: Playlist) { bundle.putParcelable(key, value) }
    override fun parseValue(value: String): Playlist = throw UnsupportedOperationException()
    override val name = "Playlist"
}
