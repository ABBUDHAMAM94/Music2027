package com.example.ymusic.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val artistId: String,
    val album: String,
    val albumId: String,
    val duration: Long, // in milliseconds
    val artworkUrl: String?,
    val audioUrl: String?,
    val isExplicit: Boolean = false,
    val isLiked: Boolean = false,
    val playCount: Long = 0,
    val trackNumber: Int = 0,
    val year: Int = 0,
    val genre: String = "",
    val lyrics: String? = null,
    val videoId: String? = null, // For YouTube Music style video playback
) : Parcelable {

    companion object {
        fun createSample(
            id: String = "song_$id",
            title: String = "Sample Song",
            artist: String = "Sample Artist",
            album: String = "Sample Album",
        ): Song = Song(
            id = id,
            title = title,
            artist = artist,
            artistId = "artist_1",
            album = album,
            albumId = "album_1",
            duration = 180000, // 3 minutes
            artworkUrl = "https://picsum.photos/seed/$id/300/300",
            audioUrl = null,
        )
    }

    fun formattedDuration(): String {
        val minutes = duration / 60000
        val seconds = (duration % 60000) / 1000
        return "%d:%02d".format(minutes, seconds)
    }

    fun copyWithLike(liked: Boolean): Song = copy(isLiked = liked)
}
