package com.example.ymusic.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.contentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ymusic.R
import com.example.ymusic.model.Song
import com.example.ymusic.player.MediaPlaybackService
import com.example.ymusic.ui.theme.YMusicTheme
import com.example.ymusic.ui.theme.ymusicCard
import com.example.ymusic.ui.theme.ymusicSurface
import androidx.coil3.compose.AsyncImage
import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.spring
import androidx.compose.material3.Divider
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.blendMode
import androidx.compose.ui.unit.Dp
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    song: Song,
    queue: List<Song>,
    index: Int,
    playbackService: MediaPlaybackService = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val isPlaying by playbackService.playbackState.collectAsStateWithLifecycle() { it == MediaPlaybackService.PlaybackState.Playing }
    val currentPosition by playbackService.currentPosition.collectAsStateWithLifecycle()
    val duration by playbackService.duration.collectAsStateWithLifecycle()
    val shuffleMode by playbackService.shuffleMode.collectAsStateWithLifecycle()
    val repeatMode by playbackService.repeatMode.collectAsStateWithLifecycle()

    val progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()) else 0f
    val animatedArtworkScale by animateFloatAsState(if (isPlaying) 1.0f else 0.95f, spring(dampingRatio = 0.8f))

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Background artwork with blur
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = song.artworkUrl,
                contentDescription = "Album art background",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                                MaterialTheme.colorScheme.background,
                                MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
        }

        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Drag handle / close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(48.dp))
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = { /* minimize */ }) {
                    Icon(Icons.Default.ExpandLess, contentDescription = "Minimize", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(24.dp))
                }
            }

            // Artwork
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .aspectRatio(1f)
                    .graphicsLayer { scaleX = animatedArtworkScale; scaleY = animatedArtworkScale }
            ) {
                AsyncImage(
                    model = song.artworkUrl,
                    contentDescription = "Album art",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(MaterialTheme.shapes.extraLarge)
                        .shadow(20.dp, MaterialTheme.colorScheme.shadow.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                )
            }

            // Song info
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = song.title,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = androidx.compose.ui.text.TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = song.artist,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = song.album,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = androidx.compose.ui.text.TextAlign.Center
                )
            }

            // Progress bar
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Slider(
                    value = progress,
                    onValueChange = { newProgress ->
                        val targetPosition = (newProgress * duration).toLong()
                        playbackService.seekTo(targetPosition)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    thumbSize = 12.dp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatTime(currentPosition), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatTime(duration), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Main controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle
                IconButton(
                    onClick = { playbackService.setShuffleMode(
                        if (shuffleMode == MediaPlaybackService.ShuffleMode.OFF)
                            MediaPlaybackService.ShuffleMode.ON
                        else MediaPlaybackService.ShuffleMode.OFF
                    ) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (shuffleMode == MediaPlaybackService.ShuffleMode.ON) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Previous
                IconButton(
                    onClick = { playbackService.skipPrevious() },
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(28.dp))
                }

                // Play/Pause
                Box(
                    modifier = Modifier.size(72.dp),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.material3.Button(
                        onClick = { playbackService.togglePlayPause() },
                        modifier = Modifier.size(64.dp),
                        shape = CircleShape,
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Next
                IconButton(
                    onClick = { playbackService.skipNext() },
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(28.dp))
                }

                // Repeat
                IconButton(
                    onClick = { playbackService.setRepeatMode(
                        when (repeatMode) {
                            MediaPlaybackService.RepeatMode.OFF -> MediaPlaybackService.RepeatMode.ALL
                            MediaPlaybackService.RepeatMode.ALL -> MediaPlaybackService.RepeatMode.ONE
                            MediaPlaybackService.RepeatMode.ONE -> MediaPlaybackService.RepeatMode.OFF
                        }
                    ) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = when (repeatMode) {
                            MediaPlaybackService.RepeatMode.OFF -> MaterialTheme.colorScheme.onSurfaceVariant
                            MediaPlaybackService.RepeatMode.ONE -> MaterialTheme.colorScheme.primary
                            MediaPlaybackService.RepeatMode.ALL -> MaterialTheme.colorScheme.primary
                        }
                    )
                }
            }

            // Secondary controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { /* queue */ }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.QueueMusic, contentDescription = "Queue", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { /* lyrics */ }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Lyrics, contentDescription = "Lyrics", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { /* like */ }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = "Like", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { /* cast */ }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Cast, contentDescription = "Cast", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Queue section
            if (queue.isNotEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Queue", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("${queue.size} songs", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 8.dp)
                    ) {
                        androidx.compose.foundation.lazy.itemsIndexed(queue) { idx, qSong ->
                            QueueItem(
                                song = qSong,
                                position = idx + 1,
                                isPlaying = idx == index && isPlaying,
                                onClick = { /* play this song */ }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QueueItem(
    song: Song,
    position: Int,
    isPlaying: Boolean,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = "$position", fontSize = 14.sp, color = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            AsyncImage(
                model = song.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier.size(40.dp).clip(MaterialTheme.shapes.small)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(text = song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                Text(text = song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isPlaying) {
                androidx.compose.material3.ProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun formatTime(ms: Long): String {
    val minutes = ms / 60000
    val seconds = (ms % 60000) / 1000
    return "%d:%02d".format(minutes, seconds)
}

// Detail screens placeholders
@Composable
fun AlbumDetailScreen(album: com.example.ymusic.model.Album) {
    ymusicSurface(Modifier.fillMaxSize()) {
        Text(text = "Album: ${album.title}", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun ArtistDetailScreen(artist: com.example.ymusic.model.Artist) {
    ymusicSurface(Modifier.fillMaxSize()) {
        Text(text = "Artist: ${artist.name}", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun PlaylistDetailScreen(playlist: com.example.ymusic.model.Playlist) {
    ymusicSurface(Modifier.fillMaxSize()) {
        Text(text = "Playlist: ${playlist.title}", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(16.dp))
    }
}
