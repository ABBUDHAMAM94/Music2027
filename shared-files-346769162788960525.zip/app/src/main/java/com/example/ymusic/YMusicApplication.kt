package com.example.ymusic

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class YMusicApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize any global configurations here
    }
}
