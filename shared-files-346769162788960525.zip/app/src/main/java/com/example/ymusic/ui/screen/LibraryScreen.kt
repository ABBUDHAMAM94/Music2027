package com.example.ymusic.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Artist
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.contentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ymusic.R
import com.example.ymusic.model.Album
import com.example.ymusic.model.Artist
import com.example.ymusic.model.Playlist
import com.example.ymusic.model.Song
import com.example.ymusic.repository.MusicRepository
import com.example.ymusic.ui.theme.YMusicTheme
import com.example.ymusic.ui.theme.ymusicCard
import com.example.ymusic.ui.theme.ymusicSurface
import androidx.coil3.compose.AsyncImage
import androidx.compose.material3.Divider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    onNavigate: (Screen) -> Unit,
    repository: MusicRepository = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val playlists = repository.playlists.collectAsStateWithLifecycle().value ?: emptyList()
    val likedSongs = repository.likedSongs.collectAsStateWithLifecycle().value ?: emptyList()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Library header with filter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.library),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = { /* filter menu */ }) {
                    Icon(Icons.Default.Menu, contentDescription = "Filter", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        // Quick access sections
        item {
            LibrarySection(
                title = "Quick access",
                items = listOf(
                    LibraryItem("Playlists", Icons.Default.PlaylistAdd, MaterialTheme.colorScheme.primary) { onNavigate(Screen.Library) },
                    LibraryItem("Songs", Icons.Default.MusicNote, MaterialTheme.colorScheme.tertiary) { onNavigate(Screen.Library) },
                    LibraryItem("Albums", Icons.Default.Album, MaterialTheme.colorScheme.secondary) { onNavigate(Screen.Library) },
                    LibraryItem("Artists", Icons.Default.Artist, Color(0xFF9C27B0)) { onNavigate(Screen.Library) },
                ),
                onClick = { it.onClick() }
            )
        }

        // Your likes
        item {
            LibrarySection(
                title = "Your likes",
                items = listOf(
                    LibraryItem("Liked songs", Icons.Default.Favorite, MaterialTheme.colorScheme.error) { /* navigate to liked songs */ },
                    LibraryItem("Your mixes", Icons.Default.QueueMusic, MaterialTheme.colorScheme.primary) { /* navigate to mixes */ },
                ),
                onClick = { it.onClick() }
            )
        }

        // Downloads
        item {
            LibrarySection(
                title = "Downloads",
                items = listOf(
                    LibraryItem("Downloaded songs", Icons.Default.Download, MaterialTheme.colorScheme.tertiary) { /* navigate to downloads */ },
                    LibraryItem("Offline mixtape", Icons.Default.History, MaterialTheme.colorScheme.secondary) { /* navigate to offline */ },
                ),
                onClick = { it.onClick() }
            )
        }

        // Your playlists
        if (playlists.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Your playlists",
                    onSeeAll = { /* navigate to all playlists */ }
                )
            }
            item {
                PlaylistsRow(
                    playlists = playlists,
                    onClick = { playlist -> onNavigate(Screen.PlaylistDetail(playlist)) }
                )
            }
        }

        // Recently added
        item {
            SectionHeader(
                title = "Recently added",
                onSeeAll = { /* navigate to recently added */ }
            )
        }
        item {
            // Placeholder for recently added
            Text("No recently added content", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun LibrarySection(
    title: String,
    items: List<LibraryItem>,
    onClick: (LibraryItem) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items.forEach { item ->
            ymusicCard(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = { onClick(item) }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(item.icon, contentDescription = item.title, tint = item.color, modifier = Modifier.size(24.dp))
                    }
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = item.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ArrowForwardIos, contentDescription = "", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

data class LibraryItem(
    val title: String,
    val icon: androidx.compose.material.icons.filled.Icon,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun SectionHeader(
    title: String,
    onSeeAll: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "See all",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun PlaylistsRow(
    playlists: List<Playlist>,
    onClick: (Playlist) -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        androidx.compose.foundation.lazy.items(playlists) { playlist ->
            PlaylistCard(
                playlist = playlist,
                onClick = { onClick(playlist) }
            )
        }
    }
}

@Composable
fun PlaylistCard(
    playlist: Playlist,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(180.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            ) {
                AsyncImage(
                    model = playlist.artworkUrl,
                    contentDescription = "Playlist art",
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .clip(MaterialTheme.shapes.medium)
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxSize()
                            .wrapContentSize(Alignment.Center)
                    )
                }
            }

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = playlist.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            Text(
                text = "${playlist.songCount} songs • ${playlist.formattedDuration()}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}
