package com.example.ymusic.repository

import com.example.ymusic.model.Album
import com.example.ymusic.model.Artist
import com.example.ymusic.model.Playlist
import com.example.ymusic.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class MusicRepository {

    // Sample data
    private val _songs = MutableStateFlow<List<Song>>(generateSampleSongs())
    private val _albums = MutableStateFlow<List<Album>>(generateSampleAlbums())
    private val _artists = MutableStateFlow<List<Artist>>(generateSampleArtists())
    private val _playlists = MutableStateFlow<List<Playlist>>(generateSamplePlaylists())
    private val _likedSongs = MutableStateFlow<MutableList<Song>>(mutableListOf())
    private val _recentlyPlayed = MutableStateFlow<MutableList<Song>>(mutableListOf())

    val songs = _songs.asStateFlow()
    val albums = _albums.asStateFlow()
    val artists = _artists.asStateFlow()
    val playlists = _playlists.asStateFlow()
    val likedSongs = _likedSongs.asStateFlow()
    val recentlyPlayed = _recentlyPlayed.asStateFlow()

    init {
        loadLikedSongs()
        loadRecentlyPlayed()
    }

    // Generate sample songs
    private fun generateSampleSongs(): List<Song> {
        val songTitles = listOf(
            "Blinding Lights", "Shape of You", "Dance Monkey", "Someone Like You",
            "Bad Guy", "Thinking Out Loud", "Roar", "Uptown Funk",
            "Hello", "Despacito", "See You Again", "Closer",
            "Love Yourself", "Sorry", "Shake It Off", "All of Me",
            "Counting Stars", "Radioactive", "Wake Me Up", "Titanium"
        )
        val artists = listOf(
            "The Weeknd", "Ed Sheeran", "Tones and I", "Adele",
            "Billie Eilish", "Ed Sheeran", "Katy Perry", "Mark Ronson ft. Bruno Mars",
            "Adele", "Luis Fonsi", "Wiz Khalifa", "The Chainsmokers",
            "Justin Bieber", "Justin Bieber", "Taylor Swift", "John Legend",
            "OneRepublic", "Imagine Dragons", "Avicii", "David Guetta ft. Sia"
        )
        val albums = listOf(
            "After Hours", "÷ (Divide)", "The Kids Are Coming", "21",
            "When We All Fall Asleep", "× (Multiply)", "Witness", "Uptown Special",
            "25", "Vida", "Furious 7", "Collage",
            "Purpose", "Purpose", "1989", "Love in the Future",
            "Native", "Night Visions", "Stories", "Listen"
        )

        return (0 until 20).map { index ->
            Song(
                id = "song_$index",
                title = songTitles[index],
                artist = artists[index],
                artistId = "artist_${index % 10}",
                album = albums[index],
                albumId = "album_${index % 10}",
                duration = (180000 + (index * 15000)).toLong(),
                artworkUrl = "https://picsum.photos/seed/song_$index/300/300",
                audioUrl = null,
                trackNumber = index + 1,
                year = 2015 + (index % 8),
                genre = listOf("Pop", "Rock", "Hip Hop", "Electronic", "R&B")[index % 5],
            )
        }
    }

    // Generate sample albums
    private fun generateSampleAlbums(): List<Album> {
        return listOf(
            Album.createSample("album_0", "After Hours", "The Weeknd", 14),
            Album.createSample("album_1", "÷ (Divide)", "Ed Sheeran", 16),
            Album.createSample("album_2", "21", "Adele", 11),
            Album.createSample("album_3", "1989", "Taylor Swift", 13),
            Album.createSample("album_4", "Purpose", "Justin Bieber", 18),
            Album.createSample("album_5", "Native", "OneRepublic", 14),
            Album.createSample("album_6", "Night Visions", "Imagine Dragons", 11),
            Album.createSample("album_7", "Witness", "Katy Perry", 15),
            Album.createSample("album_8", "Stories", "Avicii", 13),
            Album.createSample("album_9", "Listen", "David Guetta", 16),
        )
    }

    // Generate sample artists
    private fun generateSampleArtists(): List<Artist> {
        return listOf(
            Artist.createSample("artist_0", "The Weeknd"),
            Artist.createSample("artist_1", "Ed Sheeran"),
            Artist.createSample("artist_2", "Adele"),
            Artist.createSample("artist_3", "Taylor Swift"),
            Artist.createSample("artist_4", "Billie Eilish"),
            Artist.createSample("artist_5", "Justin Bieber"),
            Artist.createSample("artist_6", "Katy Perry"),
            Artist.createSample("artist_7", "Imagine Dragons"),
            Artist.createSample("artist_8", "OneRepublic"),
            Artist.createSample("artist_9", "David Guetta"),
        )
    }

    // Generate sample playlists
    private fun generateSamplePlaylists(): List<Playlist> {
        val allSongs = generateSampleSongs()
        return listOf(
            Playlist.createSample("playlist_0", "Today's Top Hits", 20).copy(
                songIds = allSongs.take(20).map { it.id }
            ),
            Playlist.createSample("playlist_1", "Pop Rising", 15).copy(
                songIds = allSongs.take(15).map { it.id }
            ),
            Playlist.createSample("playlist_2", "Chill Vibes", 18).copy(
                songIds = allSongs.drop(5).take(18).map { it.id }
            ),
            Playlist.createSample("playlist_3", "Workout Mix", 22).copy(
                songIds = allSongs.drop(2).take(22).map { it.id }
            ),
            Playlist.createSample("playlist_4", "Focus Flow", 25).copy(
                songIds = allSongs.drop(3).take(25).map { it.id }
            ),
            Playlist.createSample("playlist_5", "Throwback Thursday", 30).copy(
                songIds = allSongs.map { it.id }
            ),
        )
    }

    // Auto-generated mixes
    fun getMixes(): List<Playlist> {
        val allSongs = _songs.value.shuffled()
        return listOf(
            Playlist.createAutoMix("mix_supermix", "Supermix", "https://picsum.photos/seed/supermix/400/400", allSongs.take(50).map { it.id }),
            Playlist.createAutoMix("mix_focus", "Focus Mix", "https://picsum.photos/seed/focus/400/400", allSongs.drop(10).take(30).map { it.id }),
            Playlist.createAutoMix("mix_energy", "Energy Mix", "https://picsum.photos/seed/energy/400/400", allSongs.drop(20).take(25).map { it.id }),
            Playlist.createAutoMix("mix_chill", "Chill Mix", "https://picsum.photos/seed/chill/400/400", allSongs.drop(30).take(20).map { it.id }),
            Playlist.createAutoMix("mix_discover", "Discover Mix", "https://picsum.photos/seed/discover/400/400", allSongs.drop(40).take(30).map { it.id }),
        )
    }

    // Get song by ID
    suspend fun getSong(id: String): Song? = _songs.value.find { it.id == id }

    // Get album by ID
    suspend fun getAlbum(id: String): Album? = _albums.value.find { it.id == id }

    // Get artist by ID
    suspend fun getArtist(id: String): Artist? = _artists.value.find { it.id == id }

    // Get playlist by ID
    suspend fun getPlaylist(id: String): Playlist? = _playlists.value.find { it.id == id }

    // Search
    suspend fun search(query: String): SearchResult {
        val lowerQuery = query.lowercase()
        val songs = _songs.value.filter { it.title.lowercase().contains(lowerQuery) || it.artist.lowercase().contains(lowerQuery) }
        val albums = _albums.value.filter { it.title.lowercase().contains(lowerQuery) || it.artist.lowercase().contains(lowerQuery) }
        val artists = _artists.value.filter { it.name.lowercase().contains(lowerQuery) }
        val playlists = _playlists.value.filter { it.title.lowercase().contains(lowerQuery) }
        return SearchResult(songs, albums, artists, playlists)
    }

    // Like/Unlike song
    fun toggleLike(song: Song) {
        val liked = _likedSongs.value.toMutableList()
        if (song.isLiked) {
            liked.removeAll { it.id == song.id }
        } else {
            liked.add(song.copyWithLike(true))
        }
        _likedSongs.value = liked
    }

    // Add to recently played
    fun addToRecentlyPlayed(song: Song) {
        val recent = _recentlyPlayed.value.toMutableList()
        recent.removeAll { it.id == song.id }
        recent.add(0, song)
        if (recent.size > 50) recent.removeLast()
        _recentlyPlayed.value = recent
    }

    private fun loadLikedSongs() {
        // Load from DataStore in real app
    }

    private fun loadRecentlyPlayed() {
        // Load from DataStore in real app
    }

    data class SearchResult(
        val songs: List<Song>,
        val albums: List<Album>,
        val artists: List<Artist>,
        val playlists: List<Playlist>
    )
}
