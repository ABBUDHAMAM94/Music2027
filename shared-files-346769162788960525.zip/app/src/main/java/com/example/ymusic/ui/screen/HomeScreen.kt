package com.example.ymusic.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.contentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ymusic.R
import com.example.ymusic.model.Album
import com.example.ymusic.model.Playlist
import com.example.ymusic.model.Song
import com.example.ymusic.repository.MusicRepository
import com.example.ymusic.ui.theme.YMusicTheme
import com.example.ymusic.ui.theme.ymusicCard
import com.example.ymusic.ui.theme.ymusicSurface
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.ProgressIndicator
import androidx.coil3.compose.AsyncImage
import androidx.coil3.compose.rememberAsyncImagePainter
import androidx.compose.ui.res.stringResource

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigate: (Screen) -> Unit,
    repository: MusicRepository = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val songs = repository.songs.collectAsStateWithLifecycle().value ?: emptyList()
    val albums = repository.albums.collectAsStateWithLifecycle().value ?: emptyList()
    val playlists = repository.playlists.collectAsStateWithLifecycle().value ?: emptyList()
    val recentlyPlayed = repository.recentlyPlayed.collectAsStateWithLifecycle().value ?: emptyList()
    val mixes = repository.getMixes()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Quick picks / Recommended section
        item {
            SectionHeader(
                title = stringResource(R.string.quick_picks),
                onSeeAll = { /* navigate to quick picks */ }
            )
        }
        item {
            QuickPicksRow(
                songs = songs.shuffled().take(6),
                onPlay = { song, queue, index -> onNavigate(Screen.SongDetail(song, queue, index)) },
                onNavigate = { album -> onNavigate(Screen.AlbumDetail(album)) }
            )
        }

        // Mixes section
        item {
            SectionHeader(
                title = stringResource(R.string.mixes),
                onSeeAll = { /* navigate to mixes */ }
            )
        }
        item {
            MixesRow(
                mixes = mixes,
                onPlay = { mix, index -> 
                    val songs = repository.songs.collectAsStateWithLifecycle().value ?: emptyList()
                    val queue = mix.songIds.mapNotNull { id -> songs.find { it.id == id } }
                    if (queue.isNotEmpty()) {
                        onNavigate(Screen.SongDetail(queue[0], queue, 0))
                    }
                }
            )
        }

        // Recently played
        if (recentlyPlayed.isNotEmpty()) {
            item {
                SectionHeader(
                    title = stringResource(R.string.recently_played),
                    onSeeAll = { /* navigate to history */ }
                )
            }
            item {
                RecentlyPlayedRow(
                    songs = recentlyPlayed.take(10),
                    onPlay = { song, queue, index -> onNavigate(Screen.SongDetail(song, queue, index)) }
                )
            }
        }

        // Recommendations
        item {
            SectionHeader(
                title = stringResource(R.string.recommendations),
                onSeeAll = { /* navigate to recommendations */ }
            )
        }
        item {
            RecommendationsRow(
                items = albums.take(8),
                onClick = { album -> onNavigate(Screen.AlbumDetail(album)) }
            )
        }

        // New releases
        item {
            SectionHeader(
                title = stringResource(R.string.new_releases),
                onSeeAll = { /* navigate to new releases */ }
            )
        }
        item {
            NewReleasesRow(
                albums = albums.take(8),
                onClick = { album -> onNavigate(Screen.AlbumDetail(album)) }
            )
        }

        // Moods & Genres
        item {
            SectionHeader(
                title = stringResource(R.string.moods_genres),
                onSeeAll = { /* navigate to moods */ }
            )
        }
        item {
            MoodsGenresRow(onClick = { genre -> /* navigate to genre */ })
        }

        // Playlists
        item {
            SectionHeader(
                title = stringResource(R.string.playlists),
                onSeeAll = { /* navigate to playlists */ }
            )
        }
        item {
            PlaylistsRow(
                playlists = playlists,
                onClick = { playlist -> onNavigate(Screen.PlaylistDetail(playlist)) }
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    onSeeAll: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "See all",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun QuickPicksRow(
    songs: List<Song>,
    onPlay: (Song, List<Song>, Int) -> Unit,
    onNavigate: (Album) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(songs) { song ->
            QuickPickCard(
                song = song,
                onClick = { onPlay(song, songs, songs.indexOf(song)) }
            )
        }
    }
}

@Composable
fun QuickPickCard(
    song: Song,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(160.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Artwork
            AsyncImage(
                model = song.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            )

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = song.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            // Artist
            Text(
                text = song.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun MixesRow(
    mixes: List<Playlist>,
    onPlay: (Playlist, Int) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        itemsIndexed(mixes) { index, mix ->
            MixCard(
                mix = mix,
                index = index,
                onClick = { onPlay(mix, index) }
            )
        }
    }
}

@Composable
fun MixCard(
    mix: Playlist,
    index: Int,
    onClick: () -> Unit
) {
    val mixColors = listOf(
        Color(0xFF1A0000), Color(0xFF001A00), Color(0xFF1A1A00),
        Color(0xFF00001A), Color(0xFF1A001A), Color(0xFF001A1A)
    )
    val bgColor = mixColors[index % mixColors.size]

    ymusicCard(
        modifier = Modifier
            .width(200.dp)
            .height(200.dp)
            .background(bgColor),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.Start
        ) {
            // Top - Mix type icon
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = when {
                        mix.title.contains("Supermix") -> "Supermix"
                        mix.title.contains("Focus") -> "Focus"
                        mix.title.contains("Energy") -> "Energy"
                        mix.title.contains("Chill") -> "Chill"
                        else -> "Discover"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            // Bottom - Title and play button
            Column(
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Text(
                    text = mix.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${mix.songCount} songs • ${mix.formattedDuration()}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
                androidx.compose.material3.Button(
                    onClick = onClick,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onSurface,
                        contentColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = MaterialTheme.colorScheme.surface)
                        Text("Play", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RecentlyPlayedRow(
    songs: List<Song>,
    onPlay: (Song, List<Song>, Int) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(songs) { song ->
            RecentlyPlayedCard(
                song = song,
                onClick = { onPlay(song, songs, songs.indexOf(song)) }
            )
        }
    }
}

@Composable
fun RecentlyPlayedCard(
    song: Song,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(140.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = song.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            )

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            Text(
                text = song.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun RecommendationsRow(
    items: List<Album>,
    onClick: (Album) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(items) { album ->
            RecommendationCard(
                album = album,
                onClick = { onClick(album) }
            )
        }
    }
}

@Composable
fun RecommendationCard(
    album: Album,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(160.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = album.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            )

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = album.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            Text(
                text = album.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun NewReleasesRow(
    albums: List<Album>,
    onClick: (Album) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        albums.forEachIndexed { index, album ->
            NewReleaseItem(
                album = album,
                position = index + 1,
                onClick = { onClick(album) }
            )
        }
    }
}

@Composable
fun NewReleaseItem(
    album: Album,
    position: Int,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.fillMaxWidth().height(72.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Position number
            Text(
                text = "$position",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Artwork
            AsyncImage(
                model = album.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier
                    .size(48.dp)
                    .clip(MaterialTheme.shapes.small)
            )

            // Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = album.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = album.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Play button
            IconButton(onClick = onClick) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun MoodsGenresRow(onClick: (String) -> Unit) {
    val moods = listOf(
        "Workout" to Icons.Default.DirectionsRun,
        "Focus" to Icons.Default.Psychology,
        "Relax" to Icons.Default.Spa,
        "Commute" to Icons.Default.DirectionsCar,
        "Party" to Icons.Default.Celebration,
        "Sleep" to Icons.Default.Bedtime,
        "Pop" to Icons.Default.MusicNote,
        "Rock" to Icons.Default.MusicNote,
        "Hip Hop" to Icons.Default.MusicNote,
        "Electronic" to Icons.Default.MusicNote,
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(moods) { (title, icon) ->
            MoodGenreChip(
                title = title,
                icon = icon,
                onClick = { onClick(title) }
            )
        }
    }
}

@Composable
fun MoodGenreChip(
    title: String,
    icon: androidx.compose.material.icons.filled.Icon,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(120.dp)
            .height(120.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center
            )
        }
    }
}

@Composable
fun PlaylistsRow(
    playlists: List<Playlist>,
    onClick: (Playlist) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(playlists) { playlist ->
            PlaylistCard(
                playlist = playlist,
                onClick = { onClick(playlist) }
            )
        }
    }
}

@Composable
fun PlaylistCard(
    playlist: Playlist,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(180.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Playlist artwork with gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            ) {
                AsyncImage(
                    model = playlist.artworkUrl,
                    contentDescription = "Playlist art",
                    modifier = Modifier.fillMaxSize()
                )
                // Play indicator
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .clip(MaterialTheme.shapes.medium)
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxSize()
                            .wrapContentSize(Alignment.Center)
                    )
                }
            }

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = playlist.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            Text(
                text = "${playlist.songCount} songs • ${playlist.formattedDuration()}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}
