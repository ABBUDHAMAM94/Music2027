package com.example.ymusic.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artistId: String,
    val artworkUrl: String?,
    val releaseDate: String,
    val year: Int,
    val songCount: Int,
    val duration: Long,
    val type: AlbumType = AlbumType.ALBUM,
    val description: String = "",
    val songs: List<Song> = emptyList(),
) : Parcelable {

    enum class AlbumType {
        ALBUM, SINGLE, EP, COMPILATION, LIVE
    }

    companion object {
        fun createSample(
            id: String = "album_$id",
            title: String = "Sample Album",
            artist: String = "Sample Artist",
            songCount: Int = 10,
        ): Album = Album(
            id = id,
            title = title,
            artist = artist,
            artistId = "artist_1",
            artworkUrl = "https://picsum.photos/seed/$id/400/400",
            releaseDate = "2024-01-01",
            year = 2024,
            songCount = songCount,
            duration = songCount * 180000L,
        )
    }

    fun formattedDuration(): String {
        val hours = duration / 3600000
        val minutes = (duration % 3600000) / 60000
        return if (hours > 0) "%d hr %d min".format(hours, minutes) else "%d min".format(minutes)
    }
}
