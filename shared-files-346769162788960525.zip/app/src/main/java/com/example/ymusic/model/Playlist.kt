package com.example.ymusic.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class Playlist(
    val id: String,
    val title: String,
    val description: String = "",
    val artworkUrl: String?,
    val songIds: List<String> = emptyList(),
    val ownerId: String = "",
    val ownerName: String = "",
    val isPublic: Boolean = true,
    val isCollaborative: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val songCount: Int = songIds.size,
    val duration: Long = 0,
) : Parcelable {

    companion object {
        fun createSample(
            id: String = "playlist_$id",
            title: String = "Sample Playlist",
            songCount: Int = 15,
        ): Playlist = Playlist(
            id = id,
            title = title,
            description = "A sample playlist with $songCount songs",
            artworkUrl = "https://picsum.photos/seed/$id/400/400",
            songCount = songCount,
            duration = songCount * 180000L,
        )

        fun createAutoMix(
            id: String,
            title: String,
            artworkUrl: String?,
            songIds: List<String>,
        ): Playlist = Playlist(
            id = id,
            title = title,
            description = "Auto-generated mix",
            artworkUrl = artworkUrl,
            songIds = songIds,
            isPublic = false,
        )
    }

    fun formattedDuration(): String {
        val hours = duration / 3600000
        val minutes = (duration % 3600000) / 60000
        return if (hours > 0) "%d hr %d min".format(hours, minutes) else "%d min".format(minutes)
    }
}
