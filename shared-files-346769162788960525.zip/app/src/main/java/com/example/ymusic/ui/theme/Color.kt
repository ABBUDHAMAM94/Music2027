package com.example.ymusic.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF0000), // YouTube Music Red
    onPrimary = Color.White,
    primaryContainer = Color(0xFF410002),
    onPrimaryContainer = Color(0xFFFFDAD6),
    secondary = Color(0xFFFF3D00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF410002),
    onSecondaryContainer = Color(0xFFFFDAD6),
    tertiary = Color(0xFF00C853),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF00210A),
    onTertiaryContainer = Color(0xFFB8F5C8),
    error = Color(0xFFCF6679),
    onError = Color.White,
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0F0F0F),
    onBackground = Color.White,
    surface = Color(0xFF121212),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF1E1E1E),
    onSurfaceVariant = Color(0xFFB3B3B3),
    outline = Color(0xFF4A4A4A),
    outlineVariant = Color(0xFF333333),
    shadow = Color.Black,
    scrim = Color.Black,
    inverseSurface = Color(0xFFE6E1E5),
    inverseOnSurface = Color(0xFF313033),
    inversePrimary = Color(0xFFB3261E),
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFFF0000),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD6),
    onPrimaryContainer = Color(0xFF410002),
    secondary = Color(0xFFFF3D00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDAD6),
    onSecondaryContainer = Color(0xFF410002),
    tertiary = Color(0xFF00C853),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFB8F5C8),
    onTertiaryContainer = Color(0xFF00210A),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFEFBFF),
    onBackground = Color(0xFF1D1B1B),
    surface = Color(0xFFFEFBFF),
    onSurface = Color(0xFF1D1B1B),
    surfaceVariant = Color(0xFFE7E0E1),
    onSurfaceVariant = Color(0xFF4A4A4A),
    outline = Color(0xFF7A7576),
    outlineVariant = Color(0xFFCAC4C5),
    shadow = Color.Black,
    scrim = Color.Black,
    inverseSurface = Color(0xFF313033),
    inverseOnSurface = Color(0xFFF5F0F0),
    inversePrimary = Color(0xFFFFB4A8),
)

@Composable
fun provideColorScheme(
    darkTheme: Boolean = androidx.compose.material3.isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    androidx.compose.material3.MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}
