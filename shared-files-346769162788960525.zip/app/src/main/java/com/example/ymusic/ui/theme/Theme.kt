package com.example.ymusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object YMusicTheme {
    @Composable
    fun apply(darkTheme: Boolean = true, content: @Composable () -> Unit) {
        provideColorScheme(darkTheme, content)
    }
}

@Composable
fun ymusicSurface(
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
    color: Color = MaterialTheme.colorScheme.surface,
    shape: androidx.compose.ui.graphics.Shape = MaterialTheme.shapes.medium,
    content: @Composable () -> Unit
) {
    androidx.compose.material3.Surface(
        modifier = modifier,
        color = color,
        shape = shape,
        content = content
    )
}

@Composable
fun ymusicCard(
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    androidx.compose.material3.Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .then(if (onClick != null) androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = null
                )
            else androidx.compose.ui.Modifier),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = colors.surfaceContainer,
            pressedContainerColor = colors.surfaceContainerHigh
        ),
        shape = MaterialTheme.shapes.medium,
        content = content
    )
}
