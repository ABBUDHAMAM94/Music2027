package com.example.ymusic.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Artist
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.contentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ymusic.R
import com.example.ymusic.model.Album
import com.example.ymusic.model.Artist
import com.example.ymusic.model.Playlist
import com.example.ymusic.model.Song
import com.example.ymusic.repository.MusicRepository
import com.example.ymusic.ui.theme.YMusicTheme
import com.example.ymusic.ui.theme.ymusicCard
import com.example.ymusic.ui.theme.ymusicSurface
import androidx.coil3.compose.AsyncImage
import androidx.compose.material3.Divider
import androidx.compose.material3.ProgressIndicator
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onNavigate: (Screen) -> Unit,
    repository: MusicRepository = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    var searchQuery by remember { mutableStateOf("") }
    var showResults by remember { mutableStateOf(false) }
    val searchResults by remember {
        mutableStateOf(repository.search("").collectAsStateWithLifecycle().value)
    }

    val trendingSearches = listOf("Pop", "Rock", "Hip Hop", "Electronic", "R&B", "Indie", "K-Pop", "Latin")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Search bar
        item {
            SearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onSearchClick = {
                    showResults = true
                    // Trigger search
                },
                onVoiceClick = { /* voice search */ }
            )
        }

        // Recent searches
        if (searchQuery.isEmpty() && !showResults) {
            item {
                SectionHeader(
                    title = "Recent searches",
                    onSeeAll = { /* clear history */ }
                )
            }
            item {
                RecentSearchesRow(onClear = { /* clear history */ })
            }

            // Trending
            item {
                SectionHeader(
                    title = "Trending",
                    onSeeAll = { /* navigate to trending */ }
                )
            }
            item {
                TrendingSearchesRow(
                    searches = trendingSearches,
                    onClick = { query ->
                        searchQuery = query
                        showResults = true
                    }
                )
            }

            // Browse categories
            item {
                SectionHeader(
                    title = "Browse categories",
                    onSeeAll = { /* navigate to categories */ }
                )
            }
            item {
                BrowseCategoriesRow()
            }
        }

        // Search results
        if (showResults && searchQuery.isNotBlank()) {
            item {
                SearchResultsSection(
                    query = searchQuery,
                    results = searchResults,
                    onSongClick = { song, queue, index -> onNavigate(Screen.SongDetail(song, queue, index)) },
                    onAlbumClick = { album -> onNavigate(Screen.AlbumDetail(album)) },
                    onArtistClick = { artist -> onNavigate(Screen.ArtistDetail(artist)) },
                    onPlaylistClick = { playlist -> onNavigate(Screen.PlaylistDetail(playlist)) }
                )
            }
        }
    }
}

@Composable
fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearchClick: () -> Unit,
    onVoiceClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                .clip(MaterialTheme.shapes.medium)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(12.dp))
                TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = { Text(stringResource(R.string.search_hint), color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.textFieldColors(
                        containerColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Search),
                    singleLine = true
                )
            }
        }
        androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(8.dp))
        IconButton(onClick = onVoiceClick) {
            Icon(Icons.Default.Mic, contentDescription = "Voice search", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(48.dp).clip(MaterialTheme.shapes.full))
        }
    }
}

@Composable
fun RecentSearchesRow(onClear: () -> Unit) {
    val recent = listOf("The Weeknd", "Ed Sheeran", "Taylor Swift", "Workout mix")
    
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        recent.forEach { search ->
            ymusicCard(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = { /* repeat search */ }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.History, contentDescription = "History", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(16.dp))
                    Text(text = search, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                }
            }
        }
        // Clear all
        Text(
            text = "Clear all",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(vertical = 8.dp)
        )
    }
}

@Composable
fun TrendingSearchesRow(
    searches: List<String>,
    onClick: (String) -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        androidx.compose.foundation.lazy.items(searches) { search ->
            androidx.compose.material3.FilterChip(
                label = { Text(text = search, fontSize = 14.sp) },
                onClick = { onClick(search) },
                selected = false,
                colors = androidx.compose.material3.FilterChipDefaults.colors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    }
}

@Composable
fun BrowseCategoriesRow() {
    val categories = listOf(
        "Music" to Icons.Default.MusicNote,
        "Playlists" to Icons.Default.PlaylistAdd,
        "Artists" to Icons.Default.Artist,
        "Albums" to Icons.Default.Album,
        "Podcasts" to Icons.Default.Mic,
    )

    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        androidx.compose.foundation.lazy.items(categories) { (title, icon) ->
            ymusicCard(
                modifier = Modifier.width(120.dp).height(120.dp),
                onClick = { /* navigate to category */ }
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = androidx.compose.ui.text.TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SearchResultsSection(
    query: String,
    results: MusicRepository.SearchResult?,
    onSongClick: (Song, List<Song>, Int) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onPlaylistClick: (Playlist) -> Unit
) {
    if (results == null) return

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Songs
        if (results.songs.isNotEmpty()) {
            SectionHeader(title = "Songs", onSeeAll = { /* navigate to all songs */ })
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
            ) {
                androidx.compose.foundation.lazy.items(results.songs.take(10)) { song ->
                    SearchResultSongItem(
                        song = song,
                        onClick = { onSongClick(song, results.songs, results.songs.indexOf(song)) }
                    )
                }
            }
        }

        // Albums
        if (results.albums.isNotEmpty()) {
            SectionHeader(title = "Albums", onSeeAll = { /* navigate to all albums */ })
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
            ) {
                androidx.compose.foundation.lazy.items(results.albums.take(8)) { album ->
                    SearchResultAlbumItem(
                        album = album,
                        onClick = { onAlbumClick(album) }
                    )
                }
            }
        }

        // Artists
        if (results.artists.isNotEmpty()) {
            SectionHeader(title = "Artists", onSeeAll = { /* navigate to all artists */ })
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
            ) {
                androidx.compose.foundation.lazy.items(results.artists.take(8)) { artist ->
                    SearchResultArtistItem(
                        artist = artist,
                        onClick = { onArtistClick(artist) }
                    )
                }
            }
        }

        // Playlists
        if (results.playlists.isNotEmpty()) {
            SectionHeader(title = "Playlists", onSeeAll = { /* navigate to all playlists */ })
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
            ) {
                androidx.compose.foundation.lazy.items(results.playlists.take(8)) { playlist ->
                    SearchResultPlaylistItem(
                        playlist = playlist,
                        onClick = { onPlaylistClick(playlist) }
                    )
                }
            }
        }
    }
}

@Composable
fun SearchResultSongItem(
    song: Song,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.fillMaxWidth().height(64.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AsyncImage(
                model = song.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier.size(48.dp).clip(MaterialTheme.shapes.small)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(text = song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text(text = song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = song.formattedDuration(), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            IconButton(onClick = { /* more options */ }) {
                Icon(Icons.Default.MoreVert, contentDescription = "More", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun SearchResultAlbumItem(
    album: Album,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(160.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = album.artworkUrl,
                contentDescription = "Album art",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            Text(text = album.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
            Text(text = album.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
        }
    }
}

@Composable
fun SearchResultArtistItem(
    artist: Artist,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(140.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = artist.artworkUrl,
                contentDescription = "Artist",
                modifier = Modifier
                    .size(100.dp)
                    .clip(MaterialTheme.shapes.circle)
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            Text(text = artist.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
            Text(text = "${artist.subscriberCount} subscribers", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
        }
    }
}

@Composable
fun SearchResultPlaylistItem(
    playlist: Playlist,
    onClick: () -> Unit
) {
    ymusicCard(
        modifier = Modifier.width(180.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(MaterialTheme.shapes.medium)
            ) {
                AsyncImage(
                    model = playlist.artworkUrl,
                    contentDescription = "Playlist art",
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .clip(MaterialTheme.shapes.medium)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.fillMaxSize().wrapContentSize(Alignment.Center))
                }
            }
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            Text(text = playlist.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
            Text(text = "${playlist.songCount} songs", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
        }
    }
}
