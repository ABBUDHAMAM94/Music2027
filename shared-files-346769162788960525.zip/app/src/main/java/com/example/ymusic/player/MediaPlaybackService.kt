package com.example.ymusic.player

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaMetadata
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.MediaMetadataRetriever
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.trackselection.ExoTrackSelection
import androidx.media3.session.MediaButtonReceiver
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionCommandGroup
import androidx.media3.session.SessionPlayer
import androidx.media3.session.SessionResult
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaNotificationManager
import androidx.media3.session.MediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.controller.SessionController
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.Util
import com.example.ymusic.MainActivity
import com.example.ymusic.R
import com.example.ymusic.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

@OptIn(UnstableApi::class, androidx.media3.common.util.UnstableApi::class)
class MediaPlaybackService : MediaSessionService(), MediaNotificationProvider {

    private var exoPlayer: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val notificationManager: MediaNotificationManager by lazy { MediaNotificationManager(this) }
    
    // Playback state
    val currentSong = MutableStateFlow<Song?>(null)
    val playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val currentPosition = MutableStateFlow<Long>(0)
    val duration = MutableStateFlow<Long>(0)
    val shuffleMode = MutableStateFlow<ShuffleMode>(ShuffleMode.OFF)
    val repeatMode = MutableStateFlow<RepeatMode>(RepeatMode.OFF)
    val queue = MutableStateFlow<List<Song>>(emptyList())
    val queueIndex = MutableStateFlow<Int>(-1)

    // Notification ID
    companion object {
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "ymusic_playback"
    }

    enum class PlaybackState {
        Idle, Buffering, Playing, Paused, Error
    }

    enum class ShuffleMode {
        OFF, ON
    }

    enum class RepeatMode {
        OFF, ALL, ONE
    }

    override fun onCreate() {
        super.onCreate()
        initializePlayer()
        createNotificationChannel()
    }

    private fun initializePlayer() {
        val trackSelector = DefaultTrackSelector(this)
        exoPlayer = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            .setHandleAudioBecomingNoisy(true)
            .build()

        exoPlayer?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                val pbState = when (state) {
                    Player.STATE_IDLE -> PlaybackState.Idle
                    Player.STATE_BUFFERING -> PlaybackState.Buffering
                    Player.STATE_READY -> if (exoPlayer?.playWhenReady == true) PlaybackState.Playing else PlaybackState.Paused
                    Player.STATE_ENDED -> PlaybackState.Idle
                    else -> PlaybackState.Idle
                }
                playbackState.value = pbState
                updateNotification()
            }

            override fun onPositionChanged(position: Long) {
                currentPosition.value = position
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateCurrentSongMetadata()
            }

            override fun onPlayerError(error: androidx.media3.exoplayer.PlaybackException) {
                playbackState.value = PlaybackState.Error
            }
        })

        // Create MediaSession
        mediaSession = MediaSession.Builder(this, exoPlayer!!)
            .setId("ymusic_session")
            .setSessionCommandGroup(SessionCommandGroup(SessionCommand.COMMAND_CODE_PLAY_PAUSE,
                SessionCommand.COMMAND_CODE_SEEK_TO,
                SessionCommand.COMMAND_CODE_SKIP_TO_NEXT,
                SessionCommand.COMMAND_CODE_SKIP_TO_PREVIOUS,
                SessionCommand.COMMAND_CODE_SET_REPEAT_MODE,
                SessionCommand.COMMAND_CODE_SET_SHUFFLE_MODE))
            .setMediaNotificationProvider(this)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                CHANNEL_ID,
                "Playback",
                android.app.NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Music playback controls"
                setSound(null, null)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    // MediaNotificationProvider implementation
    override fun createNotification(mediaSession: MediaSession, controller: MediaController): Notification {
        return createCustomNotification(controller)
    }

    private fun createCustomNotification(controller: MediaController): Notification {
        val song = currentSong.value
        val isPlaying = playbackState.value == PlaybackState.Playing

        // Pending intents
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, MediaButtonReceiver::class.java).apply {
            action = if (isPlaying) "android.media.action.PAUSE" else "android.media.action.PLAY"
        }
        val playPausePendingIntent = PendingIntent.getBroadcast(this, 1, playPauseIntent, PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, MediaButtonReceiver::class.java).apply {
            action = "android.media.action.NEXT"
        }
        val nextPendingIntent = PendingIntent.getBroadcast(this, 2, nextIntent, PendingIntent.FLAG_IMMUTABLE)

        val prevIntent = Intent(this, MediaButtonReceiver::class.java).apply {
            action = "android.media.action.PREVIOUS"
        }
        val prevPendingIntent = PendingIntent.getBroadcast(this, 3, prevIntent, PendingIntent.FLAG_IMMUTABLE)

        val closeIntent = Intent(this, MediaPlaybackService::class.java).apply {
            action = "STOP_SERVICE"
        }
        val closePendingIntent = PendingIntent.getService(this, 4, closeIntent, PendingIntent.FLAG_IMMUTABLE)

        // Load artwork
        val artwork: Bitmap? = song?.artworkUrl?.let { url ->
            // In real app, load from Coil/Glide cache
            BitmapFactory.decodeResource(resources, R.drawable.ic_music_note)
        } ?: BitmapFactory.decodeResource(resources, R.drawable.ic_music_note)

        val builder = android.app.Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(artwork)
            .setContentTitle(song?.title ?: "YMusic")
            .setContentText(song?.artist ?: "Unknown Artist")
            .setSubText("${song?.album ?: "Unknown Album"} • ${formatTime(currentPosition.value)} / ${formatTime(duration.value)}")
            .setContentIntent(openPendingIntent)
            .setDeleteIntent(closePendingIntent)
            .setVisibility(android.app.Notification.VISIBILITY_PUBLIC)
            .setPriority(android.app.Notification.PRIORITY_LOW)
            .setCategory(android.app.Notification.CATEGORY_TRANSPORT)
            .setColor(ContextCompat.getColor(this, R.color.ym_red))
            .setColorized(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .addAction(R.drawable.ic_skip_previous, "Previous", prevPendingIntent)
            .addAction(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play, if (isPlaying) "Pause" else "Play", playPausePendingIntent)
            .addAction(R.drawable.ic_skip_next, "Next", nextPendingIntent)

        // Media style
        val mediaStyle = androidx.media.app.NotificationCompat.MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(0, 1, 2)
        builder.setStyle(mediaStyle)

        return builder.build()
    }

    private fun formatTime(ms: Long): String {
        val minutes = ms / 60000
        val seconds = (ms % 60000) / 1000
        return "%d:%02d".format(minutes, seconds)
    }

    // Public playback controls
    fun play(song: Song, queue: List<Song> = emptyList(), startIndex: Int = 0) {
        scope.launch {
            this.queue.value = if (queue.isNotEmpty()) queue else listOf(song)
            this.queueIndex.value = if (queue.isNotEmpty()) startIndex else 0
            currentSong.value = song
            loadAndPlay(song)
        }
    }

    private fun loadAndPlay(song: Song) {
        val audioUrl = song.audioUrl ?: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
        val mediaItem = MediaItem.fromUri(audioUrl)
        exoPlayer?.setMediaItem(mediaItem)
        exoPlayer?.prepare()
        exoPlayer?.playWhenReady = true
        updateCurrentSongMetadata()
        updateNotification()
    }

    fun togglePlayPause() {
        exoPlayer?.playWhenReady = !(exoPlayer?.playWhenReady == true)
        updateNotification()
    }

    fun pause() {
        exoPlayer?.playWhenReady = false
    }

    fun play() {
        exoPlayer?.playWhenReady = true
    }

    fun seekTo(position: Long) {
        exoPlayer?.seekTo(position)
    }

    fun skipNext() {
        val currentIndex = queueIndex.value
        val nextIndex = when (repeatMode.value) {
            RepeatMode.ONE -> currentIndex
            RepeatMode.ALL -> (currentIndex + 1) % queue.value.size
            else -> if (currentIndex + 1 < queue.value.size) currentIndex + 1 else -1
        }
        if (nextIndex >= 0 && nextIndex < queue.value.size) {
            queueIndex.value = nextIndex
            val nextSong = queue.value[nextIndex]
            currentSong.value = nextSong
            loadAndPlay(nextSong)
        }
    }

    fun skipPrevious() {
        val currentIndex = queueIndex.value
        val prevIndex = if (currentPosition.value > 3000) {
            currentIndex // Restart current song
        } else {
            when (repeatMode.value) {
                RepeatMode.ONE -> currentIndex
                RepeatMode.ALL -> (currentIndex - 1 + queue.value.size) % queue.value.size
                else -> if (currentIndex > 0) currentIndex - 1 else -1
            }
        }
        if (prevIndex >= 0 && prevIndex < queue.value.size) {
            queueIndex.value = prevIndex
            val prevSong = queue.value[prevIndex]
            currentSong.value = prevSong
            loadAndPlay(prevSong)
        }
    }

    fun setShuffleMode(mode: ShuffleMode) {
        shuffleMode.value = mode
        // Implement shuffle logic
    }

    fun setRepeatMode(mode: RepeatMode) {
        repeatMode.value = mode
        exoPlayer?.repeatMode = when (mode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
        }
    }

    fun setQueue(songs: List<Song>, startIndex: Int = 0) {
        queue.value = songs
        queueIndex.value = startIndex
        if (songs.isNotEmpty()) {
            currentSong.value = songs[startIndex]
            loadAndPlay(songs[startIndex])
        }
    }

    private fun updateCurrentSongMetadata() {
        val song = currentSong.value
        if (song != null) {
            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.artworkUrl?.let { Uri.parse(it) })
                .setDuration(duration.value)
                .build()
            mediaSession?.setMediaMetadata(metadata)
            duration.value = exoPlayer?.duration ?: song.duration
        }
    }

    private fun updateNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, createCustomNotification(mediaSession?.controller!!), android.app.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, createCustomNotification(mediaSession?.controller!!))
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        scope.cancel()
        exoPlayer?.release()
        exoPlayer = null
        mediaSession?.release()
        mediaSession = null
        notificationManager.setMediaNotificationProvider(null)
        stopForeground(true)
        super.onDestroy()
    }

    companion object {
        fun startService(context: Context, song: Song, queue: List<Song> = emptyList(), index: Int = 0) {
            val intent = Intent(context, MediaPlaybackService::class.java).apply {
                action = "PLAY"
                putExtra("song", song)
                putExtra("queue", queue)
                putExtra("index", index)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun sendCommand(context: Context, action: String) {
            val intent = Intent(context, MediaPlaybackService::class.java).apply {
                this.action = action
            }
            context.startService(intent)
        }
    }
}
